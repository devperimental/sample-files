﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AWSServiceWrapper.Shared.Types
{
    public class WrapperMessageAttributeValue
    {
        public string? DataType { get;set; }
        public string? StringValue { get; set; }
    }
}
