﻿using PolicyCompletedServiceLayer.Shared.Types;
using System;
using System.Threading.Tasks;

namespace PolicyCompletedServiceLayer.Shared.Behaviours
{
    public interface IPolicyCompletedService
    {
        Task HandlePolicyCompleted(PolicyDetail policyDetail);
    }
}
