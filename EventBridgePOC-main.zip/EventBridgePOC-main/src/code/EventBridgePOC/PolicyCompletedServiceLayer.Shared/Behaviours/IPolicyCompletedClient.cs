﻿using PolicyCompletedServiceLayer.Shared.Types;
using System.Threading.Tasks;

namespace PolicyCompletedServiceLayer.Shared.Behaviours
{
    public interface IPolicyCompletedClient
    {
        Task NotifyPolicyCompleted(PolicyDetail policyDetail);
    }
}
