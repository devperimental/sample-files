﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PolicyCompletedServiceLayer.Shared.Types
{
    public class PolicyDetail
    {
        public string? PolicyID { get; set; }
    }
}
