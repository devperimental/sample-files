﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PolicyCompletedServiceLayer.Shared.Settings
{
    public class PolicyCompletedSettings
    {
        public string? EventSource { get; set; }
        public string? EventDetailType { get; set; }
        public string? PolicyQUrl { get; set; }
        public string? PolicyDLQUrl { get; set; }
    }
}
