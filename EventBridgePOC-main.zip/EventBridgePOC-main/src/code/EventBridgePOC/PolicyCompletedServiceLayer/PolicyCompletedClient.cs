﻿using AWSServiceWrapper.Shared.Behaviours;
using AWSServiceWrapper.Shared.Types;
using Microsoft.Extensions.Logging;
using PolicyCompletedServiceLayer.Shared.Behaviours;
using PolicyCompletedServiceLayer.Shared.Settings;
using PolicyCompletedServiceLayer.Shared.Types;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace PolicyCompletedServiceLayer
{
    public class PolicyCompletedClient : IPolicyCompletedClient
    {
        private readonly PolicyCompletedSettings _policyCompletedSettings;
        private readonly ISqsWrapper _sqsWrapper;
        private readonly ILogger<PolicyCompletedClient> _logger;

        public PolicyCompletedClient(PolicyCompletedSettings policyCompletedSettings,
            ISqsWrapper sqsWrapper,
            ILogger<PolicyCompletedClient> logger)
        {
            _policyCompletedSettings = policyCompletedSettings;
            _sqsWrapper = sqsWrapper;
            _logger = logger;
        }

        public async Task NotifyPolicyCompleted(PolicyDetail policyDetail)
        {
            var messageBody = JsonSerializer.Serialize(policyDetail);

            var messageAttributes = new Dictionary<string, WrapperMessageAttributeValue>
            {
                { "PolicyID",   new WrapperMessageAttributeValue { DataType = "String", StringValue = policyDetail.PolicyID } },
                { "IdempotencyKey",  new WrapperMessageAttributeValue { DataType = "String", StringValue = Guid.NewGuid().ToString() } },
                { "SessionID", new WrapperMessageAttributeValue { DataType = "String", StringValue = Guid.NewGuid().ToString() } },
            };

            if (string.IsNullOrEmpty(_policyCompletedSettings.PolicyQUrl))
            {
                throw new ArgumentNullException(nameof(_policyCompletedSettings.PolicyQUrl));
            }

            var messageId = await _sqsWrapper.SendMessage(_policyCompletedSettings.PolicyQUrl, messageBody, messageAttributes);

            if (string.IsNullOrEmpty(messageId))
            {
                _logger.LogWarning("Unable to submit queue event for {@policyDetail}", policyDetail);
            }
        }
    }
}
