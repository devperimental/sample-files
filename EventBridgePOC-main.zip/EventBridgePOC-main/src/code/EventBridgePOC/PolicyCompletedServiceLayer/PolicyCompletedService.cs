﻿using AWSServiceWrapper.Shared.Behaviours;
using AWSServiceWrapper.Shared.Types;
using Microsoft.Extensions.Logging;
using PolicyCompletedServiceLayer.Shared.Behaviours;
using PolicyCompletedServiceLayer.Shared.Settings;
using PolicyCompletedServiceLayer.Shared.Types;
using System.Text.Json;
using System.Threading.Tasks;

namespace PolicyCompletedServiceLayer
{
    public class PolicyCompletedService : IPolicyCompletedService
    {
        private readonly PolicyCompletedSettings _policyCompletedSettings;
        private readonly IEventbridgeWrapper _eventbridgeWrapper;
        private readonly ILogger<PolicyCompletedService> _logger;

        public PolicyCompletedService(PolicyCompletedSettings policyCompletedSettings, 
            IEventbridgeWrapper eventbridgeWrapper, 
            ILogger<PolicyCompletedService> logger) {
            _policyCompletedSettings = policyCompletedSettings;
            _eventbridgeWrapper = eventbridgeWrapper;
            _logger = logger;
        }


        public async Task HandlePolicyCompleted(PolicyDetail policyDetail)
        {
            var eventBusEntry = new EventBusEntry
            {
                DetailType = _policyCompletedSettings.EventDetailType,
                Detail = JsonSerializer.Serialize(policyDetail),
                Source = _policyCompletedSettings.EventSource
            };

            var response = await _eventbridgeWrapper.PutCustomEvent(eventBusEntry);

            if (!response)
            {
                _logger.LogWarning("Unable to submit event for {@policyDetail}", policyDetail);
            }
        }
    }
}
