using Amazon.Lambda.Core;
using Amazon.Lambda.SQSEvents;
using Microsoft.Extensions.DependencyInjection;
using PolicyCompletedServiceLayer.Shared.Behaviours;
using PolicyCompletedServiceLayer.Shared.Types;
using System.Text.Json;


// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace PolicyCompletedLambda;

public class Function
{
    private IPolicyCompletedService _policyCompletedService;
    /// <summary>
    /// Default constructor. This constructor is used by Lambda to construct the instance. When invoked in a Lambda environment
    /// the AWS credentials will come from the IAM role associated with the function and the AWS region will be set to the
    /// region the Lambda function is executed in.
    /// </summary>
    public Function()
    {
        Startup.ConfigureServices();

        _policyCompletedService = Startup.Services!.GetRequiredService<IPolicyCompletedService>();
    }

    public Function(IPolicyCompletedService policyCompletedService)
    {
        _policyCompletedService = policyCompletedService;
    }


    /// <summary>
    /// This method is called for every Lambda invocation. This method takes in an SQS event object and can be used 
    /// to respond to SQS messages.
    /// </summary>
    /// <param name="evnt"></param>
    /// <param name="context"></param>
    /// <returns></returns>
    public async Task FunctionHandler(SQSEvent evnt, ILambdaContext context)
    {
        foreach(var message in evnt.Records)
        {
            await ProcessMessageAsync(message, context);
        }
    }

    private async Task ProcessMessageAsync(SQSEvent.SQSMessage message, ILambdaContext context)
    {
        context.Logger.LogInformation($"Starting processing of message {message.MessageId}");
        
        // TODO: Do interesting work based on the new message
        var policyDetail = JsonSerializer.Deserialize<PolicyDetail>(message.Body);

        if (policyDetail != null)
        {
            await _policyCompletedService.HandlePolicyCompleted(policyDetail);
            context.Logger.LogInformation($"Finished processing of message {message.MessageId} with body {message.Body}");
        }
        else
        {
            context.Logger.LogWarning($"Unable to desrialize message {message.MessageId} with body {message.Body}");
        }

        await Task.CompletedTask;
    }
}