﻿
using AWSServiceWrapper.Shared.Behaviours;
using AWSServiceWrapper.Sqs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PolicyCompletedServiceLayer;
using PolicyCompletedServiceLayer.Shared.Behaviours;
using PolicyCompletedServiceLayer.Shared.Types;

var builder = Host.CreateDefaultBuilder(args)
    .ConfigureServices(services =>
        services
            .AddTransient<ISqsWrapper, SqsWrapper>()
            .AddTransient<IPolicyCompletedClient, PolicyCompletedClient>()
    );

using IHost host = builder.Build();

await RunHarness(host.Services);

await host.RunAsync();

static async Task RunHarness(IServiceProvider hostProvider)
{
    using IServiceScope serviceScope = hostProvider.CreateScope();
    IServiceProvider provider = serviceScope.ServiceProvider;
    
    var policyCompletedClient = provider.GetRequiredService<IPolicyCompletedClient>();

    var policyDetail = new PolicyDetail
    {
        PolicyID = Guid.NewGuid().ToString()
    };

    await policyCompletedClient.NotifyPolicyCompleted(policyDetail);

    Console.WriteLine();
}
