# EventBridgePOC

cdk getting started

pre-requisites

npm -g install typescript
npm -g install aws-cdk

cdk init app --language typescript